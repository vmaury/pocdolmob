		<script src="assets/dist/js/bootstrap.bundle.min.js"></script>
		<script src="assets/common.js"></script>
	</body>
</html>
